import React from "react";
import BasicLayout from "../layouts/BasicLayout";

const AboutPage = () => {
  return (
    <BasicLayout>
      <div className="text-3xl">ABOUT PAGE</div>
    </BasicLayout>
  );
};

export default AboutPage;
