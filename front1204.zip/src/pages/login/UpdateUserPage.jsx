import UpdateUserComponent from "../../components/login/UpdateUserComponent";

const UpdateUserPage = () => {
  return (
    <div className="p-4 w-full bg-white">
      <div className="text-3xl font-extrabold">Login UpdateUser Page </div>

      <UpdateUserComponent />
    </div>
  );
};

export default UpdateUserPage;
