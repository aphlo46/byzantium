import { Suspense, lazy } from "react";
import { Navigate } from "react-router-dom";

const Loading = <div>Loading...</div>;

const LoginLogin = lazy(() => import("../pages/login/LoginPage"));
const LoginProfile = lazy(() => import("../pages/login/ProfilePage"));
const LoginRegistration = lazy(() => import("../pages/login/RegistrationPage"));
const LoginUpdateUser = lazy(() => import("../pages/login/UpdateUserPage"));
const LoginUserManagement = lazy(() =>
  import("../pages/login/UserManagementPage")
);

const loginRouter = () => {
  return [
    {
      path: "login",
      element: (
        <Suspense fallback={Loading}>
          <LoginLogin />
        </Suspense>
      ),
    },
    {
      path: "",
      element: <Navigate replace to="/login/login" />,
    },
    {
      path: "profile",
      element: (
        <Suspense fallback={Loading}>
          <LoginProfile />
        </Suspense>
      ),
    },
    {
      path: "registration",
      element: (
        <Suspense fallback={Loading}>
          <LoginRegistration />
        </Suspense>
      ),
    },
    {
      path: "updateUser",
      element: (
        <Suspense fallback={Loading}>
          <LoginUpdateUser />
        </Suspense>
      ),
    },
    {
      path: "userManagement",
      element: (
        <Suspense fallback={Loading}>
          <LoginUserManagement />
        </Suspense>
      ),
    },
  ];
};

export default loginRouter;
