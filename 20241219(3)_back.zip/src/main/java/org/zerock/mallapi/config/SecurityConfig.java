package org.zerock.mallapi.config;

import java.util.UUID;

import org.springframework.context.annotation.*;

import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.*;

import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.SecurityFilterChain;
import org.zerock.mallapi.dto.KakaoOAuth2Response;
import org.zerock.mallapi.security.BoardPrincipal;

@Configuration
public class SecurityConfig {

  @Bean
  public SecurityFilterChain securityFilterChain(
      HttpSecurity http,
      OAuth2UserService<OAuth2UserRequest, OAuth2User> oAuth2UserService) throws Exception {
    return http
        .authorizeHttpRequests(
            auth -> auth
                .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
                .mvcMatchers(
                    HttpMethod.GET,
                    "/",
                    "/articles",
                    "/articles-hashtag")
                .permitAll()
                .anyRequest().authenticated())
        .formLogin(Customizer.withDefaults())
        .logout(
            logout -> logout
                .logoutSuccessUrl("/"))
        // oauth2 로그인 추가
        .oauth2Login(
            oAuth -> oAuth
                .userInfoEndpoint(userInfo -> userInfo.userService(oAuth2UserService)))
        .build();
  }

  // OAuth2 로그인 인증
  // security로 form 로그인 구현 시 UserDetailsService.loadUserByUsername() 을 구현하는 것과 같다.
  @Bean
  public OAuth2UserService<OAuth2UserRequest, OAuth2User> oAuth2UserService(
      UserAccountService userAccountService,
      PasswordEncoder passwordEncoder) {
    final DefaultOAuth2UserService delegate = new DefaultOAuth2UserService();

    return userRequest -> {
      OAuth2User oAuth2User = delegate.loadUser(userRequest);

      KakaoOAuth2Response kakaoResponse = KakaoOAuth2Response.from(oAuth2User.getAttributes());

      String registrationId = userRequest.getClientRegistration().getRegistrationId(); // kakao
      String providerId = String.valueOf(kakaoResponse.id());
      String username = registrationId + "_" + providerId;
      String dummyPassword = passwordEncoder.encode("{bcrypt}" + UUID.randomUUID());

      return userAccountService.searchUser(username)
          .map(BoardPrincipal::from)
          .orElseGet(() -> BoardPrincipal.from(
              userAccountService.saveUser(
                  username,
                  dummyPassword,
                  kakaoResponse.email(),
                  kakaoResponse.nickname(),
                  null)));
    };
  }

}
