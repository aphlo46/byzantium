import { Suspense, lazy } from "react";
import { Navigate } from "react-router-dom";

const Loading = <div>Loading...</div>;

const LoginLogin = lazy(() => import("../pages/login/LoginPage"));
const LoginProfile = lazy(() => import("../pages/login/ProfilePage"));
const LoginUpdateUser = lazy(() => import("../pages/login/UpdateUserPage"));
const LoginUserManagement = lazy(() =>
  import("../pages/login/UserManagementPage")
);

const loginRouter = () => {
  return [
    {
      path: "login",
      element: (
        <Suspense fallback={Loading}>
          <LoginLogin />
        </Suspense>
      ),
    },
    {
      path: "profile",
      element: (
        <Suspense fallback={Loading}>
          <LoginProfile />
        </Suspense>
      ),
    },
    {
      path: "updateUser",
      element: (
        <Suspense fallback={Loading}>
          <LoginUpdateUser />
        </Suspense>
      ),
    },
    {
      path: "userManagement",
      element: (
        <Suspense fallback={Loading}>
          <LoginUserManagement />
        </Suspense>
      ),
    },
  ];
};

export default loginRouter;
