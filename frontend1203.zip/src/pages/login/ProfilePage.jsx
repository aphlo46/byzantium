import ProfileComponent from "../../components/login/ProfileComponent";

const ProfilePage = () => {
  return (
    <div className="p-4 w-full bg-white">
      <div className="text-3xl font-extrabold">Login Login Page </div>

      <ProfileComponent />
    </div>
  );
};

export default ProfilePage;
