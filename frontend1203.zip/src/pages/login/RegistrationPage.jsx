import RegistrationComponent from "../../components/login/RegistrationComponent";

const RegistrationPage = () => {
  return (
    <div className="p-4 w-full bg-white">
      <div className="text-3xl font-extrabold">Login Login Page </div>

      <RegistrationComponent />
    </div>
  );
};

export default RegistrationPage;
