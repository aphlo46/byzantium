import React from "react";
import BasicLayout from "../layouts/BasicLayout";

const MemberPage = () => {
  return (
    <BasicLayout>
      <div className="text-3xl">MEMBER PAGE</div>
    </BasicLayout>
  );
};

export default MemberPage;
