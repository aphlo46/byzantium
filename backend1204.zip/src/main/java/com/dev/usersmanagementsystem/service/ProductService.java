package com.dev.usersmanagementsystem.service;

import org.springframework.transaction.annotation.Transactional;
import com.dev.usersmanagementsystem.dto.PageRequestDTO;
import com.dev.usersmanagementsystem.dto.PageResponseDTO;
import com.dev.usersmanagementsystem.dto.ProductDTO;

@Transactional
public interface ProductService {
    PageResponseDTO<ProductDTO> getList(PageRequestDTO pageRequestDTO);

    Long register(ProductDTO productDTO);

    ProductDTO get(Long pno);

    void modify(ProductDTO productDTO);

    void remove(Long pno);
}
