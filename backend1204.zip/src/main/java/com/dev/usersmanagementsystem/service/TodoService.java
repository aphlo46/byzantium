package com.dev.usersmanagementsystem.service;

import com.dev.usersmanagementsystem.dto.PageRequestDTO;
import com.dev.usersmanagementsystem.dto.PageResponseDTO;
import com.dev.usersmanagementsystem.dto.TodoDTO;

public interface TodoService {
    Long register(TodoDTO todoDTO);

    TodoDTO get(Long tno);

    void modify(TodoDTO todoDTO);

    void remove(Long tno);

    PageResponseDTO<TodoDTO> list(PageRequestDTO pageRequestDTO);
}
