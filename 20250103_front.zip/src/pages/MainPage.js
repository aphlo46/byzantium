import BasicLayout from "../layouts/BasicLayout";

const MainPage = () => {
  return (
    <BasicLayout>
      <div className="text-3xl">MAIN PAGE</div>
    </BasicLayout>
  );
};

export default MainPage;
