import axios from "axios";
import { API_SERVER_HOST } from "./todoApi";

const rest_api_key = `817468148136-bclm20s98s8tv5cn69gbeu3msemkl7pp.apps.googleusercontent.com`; //REST key
const redirect_uri = `http://localhost:3000/member/google`;
const auth_code_path = `https://accounts.google.com/o/oauth2/v2/auth`; // Correct URL for authorization code
const access_token_url = `https://oauth2.googleapis.com/token`; // Correct URL for exchanging auth code to access token

export const getGoogleLoginLink = () => {
  const GoogleURL = `${auth_code_path}?client_id=${rest_api_key}&redirect_uri=${redirect_uri}&response_type=code`;
  return GoogleURL;
};

export const getAccessToken = async (authCode) => {
  const headers = {
    headers: {
      "Content-Type": "application/x-www-form-urlencoded", // Fixed typo here
    },
  };
  const params = new URLSearchParams({
    grant_type: "authorization_code",
    client_id: rest_api_key,
    redirect_uri: redirect_uri,
    code: authCode,
  });

  try {
    const res = await axios.post(access_token_url, params, headers);
    const accessToken = res.data.access_token;
    return accessToken;
  } catch (error) {
    console.error("Error while fetching access token:", error);
    throw error; // You may want to handle this more gracefully
  }
};

export const getMemberWithAccessToken = async (accessToken) => {
  try {
    const res = await axios.get(
      `${API_SERVER_HOST}/api/member/google?accessToken=${accessToken}`
    ); // Fixed URL issue here
    return res.data;
  } catch (error) {
    console.error("Error while fetching member data:", error);
    throw error; // Handle error appropriately
  }
};
