import BasicLayout from "../layouts/BasicLayout";

const MainPage = () => {
  return (
    <BasicLayout>
      <div className="text-3xl">MAIN PAGE</div>
      <img className="pic" w-full h-200px src="../img/001.jpg"></img>
    </BasicLayout>
  );
};

export default MainPage;
