package org.zerock.mallapi.domain;

import java.util.*;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@ToString(exclude = "memberRoleList")
public class Member {

  @Id
  private String email;
  private String pw;
  private String nickname;
  private boolean social;
  @ElementCollection
  @Builder.Default
  private List<MemberRole> memberRoleList = new ArrayList<>();

  public void addRole(MemberRole memberRole) {
    memberRoleList.add(memberRole);
  }

  public void ClearRole() {
    memberRoleList.clear();
  }

  public void ChangeNickname(String nickname) {
    this.nickname = nickname;
  }

  public void changePw(String pw) {
    this.pw = pw;
  }

  public void changeSocial(boolean social) {
    this.social = social;
  }

}
