package org.zerock.mallapi.repository;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.mallapi.domain.Product;
import org.zerock.mallapi.domain.Todo;
import org.zerock.mallapi.dto.PageRequestDTO;
import org.zerock.mallapi.dto.PageResponseDTO;
import org.zerock.mallapi.dto.ProductDTO;
import org.zerock.mallapi.service.ProductService;

import lombok.extern.log4j.Log4j2;

@SpringBootTest
@Log4j2
public class TodoRepositoryTests {
    @Autowired
    private TodoRepository todoRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductService productService;
    
    //////////////todo test///////////////////
    @Test
    public void testInsert1(){
        for(int i=0; i<= 100 ; i++){
            Todo todo = Todo.builder()
            .title("Title" + i )
            .dueDate(LocalDate.of(2024, 11, 11))
            .writer("user00")
            .build();
            
            todoRepository.save(todo);
        }
    }


    @Test
    public void testRead1(){
        Long tno = 33L;
        java.util.Optional<Todo> result = todoRepository.findById(tno);  
        Todo todo = result.orElseThrow(); 

        todo.changeTitle("Modify...");
        todo.changeComplete(true);
        todo.changeDueDate(LocalDate.of(2024, 12, 25));
        todoRepository.save(todo);

        log.info(todo);
    }

    @Test
    public void testDelete1(){
        Long tno =1L;
        todoRepository.deleteById(tno);
    }
    
    @Test
    public void testPaging(){
        Pageable pageable = PageRequest.of(0, 10, Sort.by("tno").descending());
        Page<Todo> result = todoRepository.findAll(pageable);
        log.info(result.getTotalElements());

        result.getContent().stream().forEach(todo -> log.info(todo));
    }


    ///////////////product repository test/////////////////////
    @Test
    public void testInsert(){
        for(int i=0; i<= 100 ; i++){
            Product product = Product.builder()
            .pname("상품"+i)
            .price(100*i)
            .pdesc("상품 설명 "+ i)
            .build();
            
            product.addImageString(UUID.randomUUID().toString()+"_"+"IMAGE1.jpg");
            product.addImageString(UUID.randomUUID().toString()+"_"+"IMAGE2.jpg");
            productRepository.save(product);
        }
    }


    @Transactional
    @Test
    public void testRead(){
        Long pno = 1L;

        java.util.Optional<Product> result = productRepository.findById(pno);
        Product product = result.orElseThrow(); 

        log.info(product);
        log.info(product.getImageList());
    }

    @Test
    public void testRead2(){
        Long pno = 1L;

        java.util.Optional<Product> result = productRepository.selectOne(pno);
        Product product = result.orElseThrow(); 

        log.info(product);
        log.info(product.getImageList());
    }

    @Commit
    @Transactional
    @Test
    public void testDelete(){
        Long pno = 3L;
        
        productRepository.updateToDelete(pno, true);
    }

    @Test
    public void testUpdate(){
        Long pno = 10L;

        Product product = productRepository.selectOne(pno).get();
        product.changeName("test update");
        product.changeDesc("test desc");
        product.changePrice(1111);

        //첨부 파일 수정
        product.clearList();
        product.addImageString(UUID.randomUUID().toString()+"_"+"NEWIMAGE1.jpg");
        product.addImageString(UUID.randomUUID().toString()+"_"+"NEWIMAGE2.jpg");
        product.addImageString(UUID.randomUUID().toString()+"_"+"NEWIMAGE3.jpg");


        productRepository.save(product);
    }

    @Test
    public void testList(){
        Pageable pageable = PageRequest.of(0, 10, Sort.by("pno").descending());
        Page<Object[]> result = productRepository.selectList(pageable);

        result.getContent().forEach(arr -> log.info(Arrays.toString(arr))); 
    }

    ///////////////product service test/////////////
    @Test
    public void testList2(){
        PageRequestDTO pageRequestDTO = PageRequestDTO.builder().build();
        PageResponseDTO<ProductDTO> result = productService.getList(pageRequestDTO); 

        result.getDtoList().forEach(dto -> log.info(dto));
    }

    @Test
    public void testRegister(){
        ProductDTO productDTO = ProductDTO.builder()
            .pname("register test")
            .pdesc("register test desc")
            .price(1010)
            .build();
        
        productDTO.setUploadFileNames(java.util.List.of(
            UUID.randomUUID() + "_" + "register1.jpg",
            UUID.randomUUID() + "_" + "register2.jpg"
        ));

        Long pno = productService.register(productDTO);
        log.info("register pno : " + pno);
    }

    @Test
    public void testProductRead(){
        Long pno = 7L;

        ProductDTO productDTO = productService.get(pno);

        log.info(productDTO);
        log.info(productDTO.getUploadFileNames());
    }

}
