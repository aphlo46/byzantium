package org.zerock.mallapi.user;

public enum SocialType {
    KAKAO, NAVER, GOOGLE
}
