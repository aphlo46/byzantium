package org.zerock.mallapi.service;

import java.util.*;
import org.springframework.stereotype.Service;
import org.zerock.mallapi.dto.*;
import org.zerock.mallapi.domain.*;
import org.zerock.mallapi.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RequiredArgsConstructor
@Service
@Log4j2
public class CartServiceImpl implements CartService {
  private final CartRepository cartRepository;
  private final CartItemRepository cartItemRepository;

  @Override
  public List<CartItemListDTO> addOrModify(CartItemDTO cartItemDTO) {
    String email = cartItemDTO.getEmail();
  }

}
