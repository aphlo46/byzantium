package org.zerock.mallapi.dto;

import lombok.Data;

@Data
public class CartItemDTO {
  private String email;
  private String pno;
  private int qty;
  private Long cino;

}
