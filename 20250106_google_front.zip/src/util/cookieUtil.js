import { Cookies } from "react-cookie";

const cookeis = new Cookies();
export const setCookie = (name, value, days) => {
  const expires = new Date();
  expires.setUTCDate(expires.getUTCDate() + days);
  return cookeis.set(name, value, { path: "/", expires: expires });
};
export const getCookie = (name) => {
  return cookeis.get(name);
};
export const removeCookie = (name, path = "/") => {
  cookeis.remove(name, { path });
};
