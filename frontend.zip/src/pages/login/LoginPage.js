import LoginComponent from "../../components/login/LoginComponent";

const LoginPage = () => {
  return (
    <div className="p-4 w-full bg-white">
      <div className="text-3xl font-extrabold">Login Login Page </div>

      <LoginComponent />
    </div>
  );
};

export default LoginPage;
