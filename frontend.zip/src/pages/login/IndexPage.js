import { Outlet, useNavigate } from "react-router-dom";
import BasicLayout from "../../layouts/BasicLayout";
import { useCallback } from "react";

const IndexPage = () => {
  const navigate = useNavigate();

  const handleClickLogin = useCallback(() => {
    navigate({ pathname: "login" });
  });
  const handleClickProfile = useCallback(() => {
    navigate({ pathname: "profile" });
  });
  const handleClickUpdateUser = useCallback(() => {
    navigate({ pathname: "updateUser" });
  });
  const handleClickUserManagement = useCallback(() => {
    navigate({ pathname: "userManagement" });
  });

  return (
    <BasicLayout>
      <div className="w-full flex m-2 p-2">
        <div
          className="text-xl m-1 p-2 w-20 font-extrabold text-center underline"
          onClick={handleClickLogin}
        >
          LOGIN
        </div>
        <div
          className="text-xl m-1 p-2 w-20 font-extrabold text-center underline"
          onClick={handleClickProfile}
        >
          PROFILE
        </div>
        <div
          className="text-xl m-1 p-2 w-20 font-extrabold text-center underline"
          onClick={handleClickUpdateUser}
        >
          UPDATEUSER
        </div>
        <div
          className="text-xl m-1 p-2 w-20 font-extrabold text-center underline"
          onClick={handleClickUserManagement}
        >
          USERMANAGEMENT
        </div>

        <div className="flex flex-wrap w-full">
          <Outlet />
        </div>
      </div>
    </BasicLayout>
  );
};

export default IndexPage;
